import math
import random
import struct
import array
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Callable

import pygame

# ============================================================
# 2050: LETTERS FROM THE FUTURE
# Team: TENSOR TITANS
# Single-file Python 3.13 + Pygame source code game
# ============================================================

WIDTH, HEIGHT = 1280, 720
FPS = 60
TITLE = "2050: LETTERS FROM THE FUTURE"
TEAM = "TENSOR TITANS"

# Palette
MIDNIGHT = (8, 15, 37)
DEEP_OCEAN = (16, 39, 70)
DARK_TEAL = (18, 63, 80)
ELECTRIC_CYAN = (101, 230, 242)
TURQUOISE = (57, 214, 195)
SOFT_MINT = (155, 255, 208)
ICE_BLUE = (201, 244, 255)
LAVENDER = (175, 169, 255)
CORAL = (255, 156, 203)
GOLD = (255, 217, 140)
WHITE = (245, 250, 255)
SLATE = (80, 100, 120)
SOFT_RED = (204, 110, 120)
SOFT_GREEN = (120, 210, 150)
SOFT_BLUE = (90, 170, 235)
BLACK = (8, 8, 12)

MISSION_IDS = ["river", "drain", "plant", "sort", "journey"]
MISSION_TITLES = {
    "river": "Restore the River",
    "drain": "Unclog the Drain",
    "plant": "Plant a Greener Future",
    "sort": "Sort the Waste",
    "journey": "Choose Your Journey",
}
MISSION_SDG = {
    "river": "SDG 6",
    "drain": "SDG 11",
    "plant": "SDG 13",
    "sort": "SDG 11",
    "journey": "SDG 13",
}
MISSION_DESC = {
    "river": "Remove rubbish from the river so clean water can support people and wildlife.",
    "drain": "Clear the storm drain so rainwater can flow and reduce local flooding risk.",
    "plant": "Prepare soil, plant, and water a sapling to help the neighbourhood grow greener.",
    "sort": "Put waste into the right bins to support cleaner, more sustainable communities.",
    "journey": "Choose a travel method and explore how transport decisions affect the future.",
}
MISSION_ACCENTS = {
    "river": ELECTRIC_CYAN,
    "drain": TURQUOISE,
    "plant": SOFT_MINT,
    "sort": CORAL,
    "journey": LAVENDER,
}
MISSION_BONUS = {
    "river": 120,
    "drain": 110,
    "plant": 140,
    "sort": 150,
    "journey": 100,
}

pygame.init()
pygame.font.init()


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_color(c1, c2, t):
    return (
        int(lerp(c1[0], c2[0], t)),
        int(lerp(c1[1], c2[1], t)),
        int(lerp(c1[2], c2[2], t)),
    )


def wrap_text(text, font, width):
    words = text.split()
    lines = []
    current = ""
    for word in words:
        test = word if not current else current + " " + word
        if font.size(test)[0] <= width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_text(surface, text, font, color, rect, align="topleft", line_spacing=4):
    lines = wrap_text(text, font, rect.width)
    y = rect.y
    for line in lines:
        img = font.render(line, True, color)
        x = rect.x
        if align == "center":
            x = rect.centerx - img.get_width() // 2
        elif align == "topright":
            x = rect.right - img.get_width()
        surface.blit(img, (x, y))
        y += img.get_height() + line_spacing
    return y


def vertical_gradient(size, top_color, bottom_color):
    surf = pygame.Surface(size)
    w, h = size
    for y in range(h):
        t = y / max(1, h - 1)
        color = lerp_color(top_color, bottom_color, t)
        pygame.draw.line(surf, color, (0, y), (w, y))
    return surf


def radial_glow(radius, color, alpha=160):
    surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    for r in range(radius, 0, -1):
        a = int(alpha * (r / radius) ** 2 * 0.18)
        pygame.draw.circle(surf, (*color, a), (radius, radius), r)
    return surf


def rounded_rect(surface, rect, color, radius=18, border=0, border_color=None):
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    if border > 0 and border_color:
        pygame.draw.rect(surface, border_color, rect, border, border_radius=radius)


def draw_starfield(surface, stars, twinkle):
    for x, y, s, phase in stars:
        a = int(90 + 120 * (0.5 + 0.5 * math.sin(twinkle * 1.8 + phase)))
        col = (255, 255, 255, a)
        pygame.draw.circle(surface, WHITE, (int(x), int(y)), s)
        if s > 1:
            g = radial_glow(8, ICE_BLUE, alpha=a)
            surface.blit(g, (x - 8, y - 8), special_flags=pygame.BLEND_ALPHA_SDL2)


@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    life: float
    max_life: float
    color: Tuple[int, int, int]
    size: float
    gravity: float = 0.0
    fade: bool = True

    def update(self, dt):
        self.life -= dt
        self.vy += self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        return self.life > 0

    def draw(self, surface):
        if self.life <= 0:
            return
        t = self.life / self.max_life if self.max_life else 0
        radius = max(1, int(self.size * (0.5 + 0.5 * t)))
        if self.fade:
            glow = pygame.Surface((radius * 6, radius * 6), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*self.color, int(140 * t)), (radius * 3, radius * 3), radius)
            surface.blit(glow, (self.x - radius * 3, self.y - radius * 3))
        else:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), radius)


class ParticleSystem:
    def __init__(self):
        self.particles: List[Particle] = []

    def emit_burst(self, x, y, color, count=12, speed=120, spread=math.pi * 2, life=0.7, gravity=0):
        for _ in range(count):
            ang = random.random() * spread
            vel = speed * (0.35 + random.random() * 0.85)
            self.particles.append(
                Particle(x, y, math.cos(ang) * vel, math.sin(ang) * vel, life, life, color, random.uniform(2, 5), gravity)
            )

    def emit_droplets(self, x, y, color, count=10):
        for _ in range(count):
            self.particles.append(
                Particle(
                    x + random.uniform(-12, 12),
                    y + random.uniform(-8, 8),
                    random.uniform(-25, 25),
                    random.uniform(-130, -40),
                    0.8,
                    0.8,
                    color,
                    random.uniform(2, 4),
                    gravity=180,
                )
            )

    def update(self, dt):
        self.particles = [p for p in self.particles if p.update(dt)]

    def draw(self, surface):
        for p in self.particles:
            p.draw(surface)


class SafeAudio:
    def __init__(self):
        self.available = False
        self.music_enabled = True
        self.sfx_enabled = True
        self.volume = 0.45
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        self.music_channels: List[pygame.mixer.Channel] = []
        try:
            pygame.mixer.pre_init(44100, -16, 1, 512)
            pygame.mixer.init()
            self.available = True
            self._build_sfx()
            self._start_music()
        except Exception:
            self.available = False

    def _tone_samples(self, freq=440.0, duration=0.25, vol=0.25, wave="sine", decay=True):
        sample_rate = 44100
        n = int(sample_rate * duration)
        buf = array.array("h")
        for i in range(n):
            t = i / sample_rate
            env = 1.0
            if decay:
                env = math.exp(-3.0 * t / max(0.001, duration))
            if wave == "sine":
                s = math.sin(2 * math.pi * freq * t)
            elif wave == "triangle":
                s = 2 * abs(2 * ((freq * t) % 1) - 1) - 1
            elif wave == "soft":
                s = 0.7 * math.sin(2 * math.pi * freq * t) + 0.3 * math.sin(2 * math.pi * freq * 2 * t)
            else:
                s = math.sin(2 * math.pi * freq * t)
            value = int(max(-1, min(1, s * vol * env)) * 32767)
            buf.append(value)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _build_sfx(self):
        try:
            self.sounds["click"] = self._tone_samples(720, 0.08, 0.18, "soft")
            self.sounds["collect"] = self._tone_samples(560, 0.14, 0.24, "triangle")
            self.sounds["plant"] = self._tone_samples(410, 0.18, 0.22, "soft")
            self.sounds["water"] = self._tone_samples(880, 0.12, 0.16, "sine")
            self.sounds["sort"] = self._tone_samples(660, 0.1, 0.18, "soft")
            self.sounds["complete"] = self._chord([392, 523, 659], 0.5, 0.18)
            self.sounds["error"] = self._tone_samples(210, 0.12, 0.18, "triangle")
            for snd in self.sounds.values():
                snd.set_volume(self.volume)
        except Exception:
            self.available = False

    def _chord(self, freqs, duration, vol):
        sample_rate = 44100
        n = int(sample_rate * duration)
        buf = array.array("h")
        for i in range(n):
            t = i / sample_rate
            env = math.exp(-2.0 * t / max(duration, 0.001))
            s = 0.0
            for f in freqs:
                s += math.sin(2 * math.pi * f * t)
            s /= max(1, len(freqs))
            value = int(max(-1, min(1, s * vol * env)) * 32767)
            buf.append(value)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _start_music(self):
        if not self.available:
            return
        try:
            notes = [220, 261.63, 329.63, 392.0, 349.23, 293.66, 329.63, 261.63]
            bass = [110, 130.81, 164.81, 196, 174.61, 146.83, 164.81, 130.81]
            melody_parts = []
            bass_parts = []
            for n in notes:
                melody_parts.append(self._tone_samples(n, 0.48, 0.08, "soft"))
            for n in bass:
                bass_parts.append(self._tone_samples(n, 0.48, 0.07, "sine"))
            ch1 = pygame.mixer.Channel(2)
            ch2 = pygame.mixer.Channel(3)
            self.music_channels = [ch1, ch2]
            self.music_sequence = melody_parts
            self.bass_sequence = bass_parts
            self.music_index = 0
            self.music_timer = 0.0
        except Exception:
            self.available = False

    def update(self, dt):
        if not self.available or not self.music_enabled or not hasattr(self, "music_sequence"):
            return
        self.music_timer -= dt
        if self.music_timer <= 0:
            snd1 = self.music_sequence[self.music_index % len(self.music_sequence)]
            snd2 = self.bass_sequence[self.music_index % len(self.bass_sequence)]
            self.music_channels[0].play(snd1)
            self.music_channels[1].play(snd2)
            self.music_index += 1
            self.music_timer = 0.44

    def play(self, name):
        if not self.available or not self.sfx_enabled:
            return
        snd = self.sounds.get(name)
        if snd:
            try:
                snd.set_volume(self.volume)
                snd.play()
            except Exception:
                pass

    def toggle_music(self):
        self.music_enabled = not self.music_enabled
        if self.available and not self.music_enabled:
            try:
                for c in self.music_channels:
                    c.stop()
            except Exception:
                pass

    def toggle_sfx(self):
        self.sfx_enabled = not self.sfx_enabled

    def set_volume(self, v):
        self.volume = clamp(v, 0.0, 1.0)
        for snd in self.sounds.values():
            try:
                snd.set_volume(self.volume)
            except Exception:
                pass


class Button:
    def __init__(self, rect, text, action=None, accent=ELECTRIC_CYAN, small=False):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.action = action
        self.accent = accent
        self.small = small
        self.hover = False
        self.enabled = True

    def draw(self, surface, fonts):
        base = (25, 38, 60) if self.enabled else (40, 45, 55)
        fill = lerp_color(base, self.accent, 0.18 if self.hover and self.enabled else 0.08)
        rounded_rect(surface, self.rect, fill, radius=16, border=2, border_color=lerp_color(self.accent, WHITE, 0.25))
        if self.hover and self.enabled:
            g = radial_glow(max(self.rect.width, self.rect.height) // 2, self.accent, alpha=90)
            surface.blit(g, (self.rect.centerx - g.get_width() // 2, self.rect.centery - g.get_height() // 2), special_flags=pygame.BLEND_ALPHA_SDL2)
        font = fonts["body"] if self.small else fonts["sub"]
        img = font.render(self.text, True, WHITE if self.enabled else (170, 180, 190))
        surface.blit(img, img.get_rect(center=self.rect.center))

    def handle_event(self, event, audio=None):
        if not self.enabled:
            return False
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if audio:
                    audio.play("click")
                if self.action:
                    self.action()
                return True
        return False


class InputBox:
    def __init__(self, rect, text=""):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.active = True
        self.cursor_timer = 0.0
        self.cursor_visible = True

    def update(self, dt):
        self.cursor_timer += dt
        if self.cursor_timer >= 0.5:
            self.cursor_timer = 0.0
            self.cursor_visible = not self.cursor_visible

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.active = self.rect.collidepoint(event.pos)
        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.key == pygame.K_RETURN:
                return "submit"
            else:
                if len(self.text) < 18 and event.unicode.isprintable() and event.unicode not in "\t\r\n":
                    self.text += event.unicode
        return None

    def draw(self, surface, fonts):
        rounded_rect(surface, self.rect, (18, 28, 46), radius=16, border=2, border_color=ELECTRIC_CYAN if self.active else SLATE)
        shown = self.text if self.text else "Enter your name..."
        color = WHITE if self.text else (130, 150, 170)
        img = fonts["sub"].render(shown, True, color)
        surface.blit(img, (self.rect.x + 16, self.rect.y + self.rect.height // 2 - img.get_height() // 2))
        if self.active and self.cursor_visible:
            cursor_x = self.rect.x + 16 + img.get_width() + (0 if self.text else 0)
            pygame.draw.line(surface, ELECTRIC_CYAN, (cursor_x + 3, self.rect.y + 14), (cursor_x + 3, self.rect.bottom - 14), 2)


class TypewriterLetter:
    def __init__(self, title, body):
        self.title = title
        self.body = body
        self.visible_chars = 0
        self.speed = 90.0
        self.done = False

    def reset(self):
        self.visible_chars = 0
        self.done = False

    def update(self, dt):
        if self.done:
            return
        self.visible_chars += self.speed * dt
        if self.visible_chars >= len(self.body):
            self.visible_chars = len(self.body)
            self.done = True

    def reveal_all(self):
        self.visible_chars = len(self.body)
        self.done = True

    def current_text(self):
        return self.body[: int(self.visible_chars)]

    def draw(self, surface, fonts, rect):
        panel = pygame.Rect(rect)
        rounded_rect(surface, panel, (242, 245, 250), radius=24, border=3, border_color=(210, 220, 235))
        inner = panel.inflate(-34, -34)
        title_img = fonts["title_small"].render(self.title, True, DEEP_OCEAN)
        surface.blit(title_img, (inner.x, inner.y))
        line_y = inner.y + title_img.get_height() + 10
        pygame.draw.line(surface, (190, 205, 225), (inner.x, line_y), (inner.right, line_y), 2)
        text_rect = pygame.Rect(inner.x, line_y + 18, inner.width, inner.height - 26)
        draw_text(surface, self.current_text(), fonts["body"], (35, 52, 82), text_rect)
        hint = "Click / Enter / Space to reveal or continue"
        hint_img = fonts["small"].render(hint, True, (80, 95, 120))
        surface.blit(hint_img, (panel.right - hint_img.get_width() - 20, panel.bottom - hint_img.get_height() - 14))


@dataclass
class ProgressData:
    player_name: str = ""
    score: int = 0
    completed_unique: set = field(default_factory=set)
    mission_first_bonus_given: set = field(default_factory=set)
    sdgs: set = field(default_factory=set)
    achievements: List[str] = field(default_factory=list)
    travel_choice: Optional[str] = None

    def reset(self):
        self.player_name = ""
        self.score = 0
        self.completed_unique.clear()
        self.mission_first_bonus_given.clear()
        self.sdgs.clear()
        self.achievements.clear()
        self.travel_choice = None


# ------------------------------------------------------------
# Procedural scenery helpers
# ------------------------------------------------------------

def draw_building(surface, x, base_y, width, height, color, window_color, seed=0):
    random.seed(seed)
    rect = pygame.Rect(x, base_y - height, width, height)
    pygame.draw.rect(surface, color, rect, border_radius=4)
    for ix in range(rect.x + 10, rect.right - 10, 16):
        for iy in range(rect.y + 10, rect.bottom - 12, 18):
            if random.random() > 0.28:
                wc = window_color if random.random() > 0.3 else lerp_color(window_color, GOLD, 0.25)
                pygame.draw.rect(surface, wc, (ix, iy, 8, 10), border_radius=2)


def draw_skyline(surface, t):
    bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DEEP_OCEAN)
    surface.blit(bg, (0, 0))
    moon_pos = (1040, 120)
    moon = radial_glow(90, ICE_BLUE, alpha=200)
    surface.blit(moon, (moon_pos[0] - 90, moon_pos[1] - 90))
    pygame.draw.circle(surface, (230, 245, 255), moon_pos, 42)
    for i in range(8):
        draw_building(surface, 40 + i * 150, 500 + (i % 3) * 18, 90 + (i % 4) * 20, 180 + (i * 27 % 170), (18 + i * 5, 30 + i * 4, 55 + i * 3), (120, 220, 235), i)
    for i in range(7):
        draw_building(surface, 90 + i * 170, 560, 120, 110 + (i * 39 % 140), (10, 22, 40), (90, 170, 200), i + 30)
    pygame.draw.rect(surface, (12, 18, 30), (0, 560, WIDTH, 160))
    river_rect = pygame.Rect(0, 510, WIDTH, 210)
    water_col = lerp_color((10, 30, 46), (20, 70, 92), 0.5 + 0.2 * math.sin(t * 0.7))
    pygame.draw.rect(surface, water_col, river_rect)
    for i in range(16):
        x = i * 90 + (t * 30) % 90
        pygame.draw.line(surface, (90, 160, 180), (x, 550 + 10 * math.sin(i + t)), (x + 50, 556 + 10 * math.sin(i + t)), 2)
    draw_bridge(surface, 290, 450, 690, 120, glow=True)


def draw_bridge(surface, x1, y, x2, arch_h, glow=False):
    road_y = y + 36
    pygame.draw.line(surface, (70, 85, 110), (x1, road_y), (x2, road_y), 8)
    pygame.draw.line(surface, (170, 190, 215), (x1, road_y - 6), (x2, road_y - 6), 2)
    cx = (x1 + x2) // 2
    points = []
    for i in range(41):
        t = i / 40
        x = int(lerp(x1, x2, t))
        xx = (t - 0.5) * 2
        yy = int(y - arch_h * (1 - xx * xx))
        points.append((x, yy))
    pygame.draw.lines(surface, (135, 155, 190), False, points, 5)
    for i in range(0, 41, 4):
        px, py = points[i]
        pygame.draw.line(surface, (120, 140, 170), (px, py), (px, road_y), 2)
        if glow:
            pygame.draw.circle(surface, GOLD, (px, py + 16), 2)


def draw_tree(surface, x, y, scale=1.0, lush=1.0):
    trunk_w = int(14 * scale)
    trunk_h = int(50 * scale)
    pygame.draw.rect(surface, (100, 66, 35), (x - trunk_w // 2, y - trunk_h, trunk_w, trunk_h), border_radius=4)
    leaf_col = lerp_color((60, 120, 70), SOFT_MINT, clamp(lush, 0, 1) * 0.55)
    for dx, dy, r in [(-20, -48, 22), (0, -62, 28), (24, -46, 20), (-6, -36, 24)]:
        pygame.draw.circle(surface, leaf_col, (int(x + dx * scale), int(y + dy * scale)), int(r * scale))


def draw_reed(surface, x, y, h=30):
    pygame.draw.line(surface, (70, 170, 120), (x, y), (x + 3, y - h), 2)
    pygame.draw.line(surface, (90, 190, 130), (x + 4, y), (x + 7, y - h + 6), 2)


def draw_waste_item(surface, item_type, rect, angle=0, highlight=False):
    cx, cy = rect.center
    color_outline = WHITE if highlight else (18, 30, 44)
    temp = pygame.Surface(rect.size, pygame.SRCALPHA)
    r = pygame.Rect(0, 0, rect.width, rect.height)
    if item_type == "bottle":
        pygame.draw.rect(temp, (120, 220, 245), (r.w * 0.30, r.h * 0.18, r.w * 0.34, r.h * 0.58), border_radius=8)
        pygame.draw.rect(temp, (80, 170, 210), (r.w * 0.39, r.h * 0.08, r.w * 0.15, r.h * 0.14), border_radius=4)
        pygame.draw.rect(temp, WHITE, (r.w * 0.34, r.h * 0.38, r.w * 0.25, r.h * 0.12), border_radius=3)
    elif item_type == "can":
        pygame.draw.ellipse(temp, (185, 205, 220), (r.w * 0.26, r.h * 0.18, r.w * 0.48, r.h * 0.22))
        pygame.draw.rect(temp, (165, 185, 200), (r.w * 0.26, r.h * 0.28, r.w * 0.48, r.h * 0.38))
        pygame.draw.ellipse(temp, (205, 225, 235), (r.w * 0.26, r.h * 0.54, r.w * 0.48, r.h * 0.22))
        pygame.draw.rect(temp, CORAL, (r.w * 0.30, r.h * 0.36, r.w * 0.40, r.h * 0.10), border_radius=3)
    elif item_type == "wrapper":
        pts = [(r.w * 0.18, r.h * 0.42), (r.w * 0.30, r.h * 0.28), (r.w * 0.70, r.h * 0.34), (r.w * 0.82, r.h * 0.50), (r.w * 0.68, r.h * 0.68), (r.w * 0.28, r.h * 0.62)]
        pygame.draw.polygon(temp, (220, 120, 170), pts)
        pygame.draw.line(temp, WHITE, pts[1], pts[4], 2)
    elif item_type == "bag":
        pygame.draw.polygon(temp, (190, 190, 205), [(r.w * 0.28, r.h * 0.24), (r.w * 0.72, r.h * 0.24), (r.w * 0.82, r.h * 0.76), (r.w * 0.20, r.h * 0.76)])
        pygame.draw.arc(temp, (160, 160, 175), (r.w * 0.35, r.h * 0.12, r.w * 0.30, r.h * 0.24), math.pi, math.tau, 3)
    elif item_type == "paper":
        pygame.draw.rect(temp, (245, 245, 240), (r.w * 0.22, r.h * 0.18, r.w * 0.52, r.h * 0.58), border_radius=4)
        for i in range(4):
            pygame.draw.line(temp, (180, 190, 200), (r.w * 0.28, r.h * (0.30 + i * 0.10)), (r.w * 0.66, r.h * (0.30 + i * 0.10)), 2)
    elif item_type == "cardboard":
        pygame.draw.rect(temp, (176, 126, 82), (r.w * 0.18, r.h * 0.26, r.w * 0.60, r.h * 0.42), border_radius=4)
        pygame.draw.line(temp, (130, 90, 55), (r.w * 0.48, r.h * 0.26), (r.w * 0.48, r.h * 0.68), 2)
    elif item_type == "peel":
        pygame.draw.arc(temp, (255, 210, 80), (r.w * 0.20, r.h * 0.24, r.w * 0.56, r.h * 0.44), 0.4, 2.7, 7)
    elif item_type == "leaf":
        pygame.draw.ellipse(temp, (85, 190, 110), (r.w * 0.24, r.h * 0.22, r.w * 0.50, r.h * 0.42))
        pygame.draw.line(temp, (50, 120, 70), (r.w * 0.30, r.h * 0.58), (r.w * 0.62, r.h * 0.28), 2)
    rotated = pygame.transform.rotate(temp, angle)
    dest = rotated.get_rect(center=(cx, cy))
    surface.blit(rotated, dest.topleft)
    if highlight:
        pygame.draw.rect(surface, color_outline, rect, 2, border_radius=10)


def draw_bin(surface, rect, color, label, active=False):
    rounded_rect(surface, rect, lerp_color((30, 42, 56), color, 0.35), radius=18, border=3, border_color=color if active else (180, 190, 200))
    lid = pygame.Rect(rect.x + 10, rect.y - 12, rect.width - 20, 18)
    rounded_rect(surface, lid, lerp_color(color, WHITE, 0.2), radius=8)
    slot = pygame.Rect(rect.centerx - 28, rect.y + 16, 56, 8)
    rounded_rect(surface, slot, (24, 32, 40), radius=4)
    img = pygame.font.SysFont("arial", 20, bold=True).render(label, True, WHITE)
    surface.blit(img, img.get_rect(center=(rect.centerx, rect.bottom - 30)))


def draw_progress_bar(surface, rect, value, max_value, color):
    pygame.draw.rect(surface, (30, 42, 56), rect, border_radius=999)
    ratio = 0 if max_value <= 0 else clamp(value / max_value, 0, 1)
    fill = pygame.Rect(rect.x, rect.y, int(rect.width * ratio), rect.height)
    pygame.draw.rect(surface, color, fill, border_radius=999)
    pygame.draw.rect(surface, (170, 190, 210), rect, 2, border_radius=999)


def draw_panel(surface, rect, alpha=210):
    panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    rounded_rect(panel, panel.get_rect(), (10, 18, 34, alpha), radius=24, border=2, border_color=(120, 170, 210))
    surface.blit(panel, rect.topleft)


# ------------------------------------------------------------
# Mission classes
# ------------------------------------------------------------

class MissionBase:
    def __init__(self, game, mission_id):
        self.game = game
        self.id = mission_id
        self.complete = False
        self.local_score = 0
        self.message = ""
        self.message_timer = 0.0
        self.back_button = Button((1040, 24, 200, 48), "Return to Hub", self.return_to_hub, accent=LAVENDER, small=True)

    def award_points(self, pts):
        self.local_score += pts
        self.game.progress.score += pts

    def first_completion_bonus(self):
        if self.id not in self.game.progress.mission_first_bonus_given:
            self.game.progress.mission_first_bonus_given.add(self.id)
            self.game.progress.score += MISSION_BONUS[self.id]
            self.game.audio.play("complete")
            return True
        return False

    def mark_completed(self, achievement=None):
        if self.id not in self.game.progress.completed_unique:
            self.game.progress.completed_unique.add(self.id)
            self.game.progress.sdgs.add(MISSION_SDG[self.id])
            if achievement and achievement not in self.game.progress.achievements:
                self.game.progress.achievements.append(achievement)
        self.complete = True
        self.first_completion_bonus()

    def return_to_hub(self):
        self.game.switch_screen(self.game.hub)

    def set_message(self, text, timer=2.0):
        self.message = text
        self.message_timer = timer

    def common_update(self, dt):
        if self.message_timer > 0:
            self.message_timer -= dt
            if self.message_timer <= 0:
                self.message = ""

    def common_draw(self, surface, title, instruction, accent):
        title_img = self.game.fonts["title_small"].render(title, True, WHITE)
        surface.blit(title_img, (30, 20))
        sdg_img = self.game.fonts["body"].render(MISSION_SDG[self.id], True, accent)
        surface.blit(sdg_img, (34, 70))
        draw_panel(surface, pygame.Rect(28, 100, 420, 94))
        draw_text(surface, instruction, self.game.fonts["body"], ICE_BLUE, pygame.Rect(48, 120, 380, 62))
        self.back_button.draw(surface, self.game.fonts)
        if self.message:
            msg_rect = pygame.Rect(420, 24, 400, 54)
            rounded_rect(surface, msg_rect, (14, 30, 42), radius=16, border=2, border_color=accent)
            txt = self.game.fonts["body"].render(self.message, True, WHITE)
            surface.blit(txt, txt.get_rect(center=msg_rect.center))

    def handle_back_button(self, event):
        self.back_button.handle_event(event, self.game.audio)


class RiverMission(MissionBase):
    def __init__(self, game):
        super().__init__(game, "river")
        self.reset_local()

    def reset_local(self):
        self.items = []
        self.collected = set()
        positions = [
            (260, 360, "bottle", 18), (360, 430, "can", -10), (520, 330, "wrapper", 12),
            (640, 390, "bag", -7), (760, 320, "bottle", -18), (900, 430, "can", 13),
            (1080, 350, "wrapper", -11), (700, 500, "bag", 6),
        ]
        for i, (x, y, typ, ang) in enumerate(positions):
            self.items.append({"id": i, "rect": pygame.Rect(x, y, 64, 64), "type": typ, "angle": ang, "done": False})
        self.target = len(self.items)
        self.ripple = 0.0
        self.particles = ParticleSystem()
        self.complete = False
        self.local_score = 0

    def update(self, dt):
        self.ripple += dt
        self.particles.update(dt)
        self.common_update(dt)
        if all(it["done"] for it in self.items) and not self.complete:
            self.mark_completed("River Restorer")
            self.set_message("The river is flowing clean again!", 2.8)

    def handle_event(self, event):
        self.handle_back_button(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for item in self.items:
                if not item["done"] and item["rect"].collidepoint(event.pos):
                    item["done"] = True
                    self.collected.add(item["id"])
                    self.award_points(20)
                    self.particles.emit_burst(item["rect"].centerx, item["rect"].centery, ELECTRIC_CYAN, count=14, speed=110)
                    self.game.audio.play("collect")
                    self.set_message("Rubbish collected", 1.2)
                    break

    def draw(self, surface):
        progress = len(self.collected) / self.target
        sky = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DARK_TEAL)
        surface.blit(sky, (0, 0))
        for i in range(6):
            draw_building(surface, 50 + i * 200, 255, 110 + (i % 2) * 30, 110 + i * 18, (20, 38, 60), (90, 180, 220), i + 100)
        river_color = lerp_color((85, 95, 110), (55, 214, 195), progress)
        bright_color = lerp_color((105, 110, 120), (201, 244, 255), progress)
        bank_pts_top = [(0, 280), (170, 260), (350, 275), (550, 250), (760, 272), (980, 248), (1280, 270)]
        bank_pts_bottom = [(0, 640), (180, 610), (380, 630), (650, 605), (900, 640), (1120, 612), (1280, 628)]
        pygame.draw.polygon(surface, (36, 74, 58), bank_pts_top + [(1280, 0), (0, 0)])
        pygame.draw.polygon(surface, (46, 88, 66), bank_pts_bottom + [(1280, 720), (0, 720)])
        river_poly = [(0, 300), (180, 285), (380, 315), (650, 280), (880, 320), (1140, 292), (1280, 310), (1280, 610), (1110, 594), (850, 622), (630, 586), (380, 618), (160, 590), (0, 610)]
        pygame.draw.polygon(surface, river_color, river_poly)
        for i in range(12):
            px = i * 120
            py = 340 + 90 * math.sin(i * 0.5)
            pygame.draw.line(surface, bright_color, (px, py + math.sin(self.ripple * 2 + i) * 8), (px + 90, py + 4 + math.sin(self.ripple * 2 + i) * 8), 2)
        for rx in [120, 250, 430, 860, 1040]:
            draw_reed(surface, rx, 295, 26)
            draw_reed(surface, rx + 10, 596, 24)
        for rock in [(180, 610, 24), (375, 620, 18), (1020, 605, 20), (540, 272, 16), (940, 286, 12)]:
            pygame.draw.ellipse(surface, (110, 110, 120), (rock[0], rock[1], rock[2] * 1.8, rock[2]))
        for item in self.items:
            if not item["done"]:
                draw_waste_item(surface, item["type"], item["rect"], item["angle"], highlight=False)
        if progress > 0.25:
            for i in range(int(progress * 8)):
                draw_reed(surface, 960 + i * 18, 285, 30 + i * 2)
                draw_reed(surface, 220 + i * 18, 603, 24 + i * 2)
        self.particles.draw(surface)
        self.common_draw(surface, "Mission 1 — Restore the River", "Click every unique piece of rubbish. As you clean the river, the water becomes clearer for communities and wildlife.", ELECTRIC_CYAN)
        draw_panel(surface, pygame.Rect(24, 620, 430, 74))
        info = self.game.fonts["body"].render(f"Collected: {len(self.collected)} / {self.target}   •   Score +20 each", True, WHITE)
        surface.blit(info, (42, 640))
        draw_progress_bar(surface, pygame.Rect(42, 670, 390, 14), len(self.collected), self.target, ELECTRIC_CYAN)


class DrainMission(MissionBase):
    def __init__(self, game):
        super().__init__(game, "drain")
        self.reset_local()

    def reset_local(self):
        self.items = []
        positions = [
            (560, 360, "bag"), (610, 345, "wrapper"), (660, 380, "bottle"),
            (715, 350, "can"), (770, 375, "wrapper"), (630, 420, "paper"),
        ]
        for i, (x, y, typ) in enumerate(positions):
            self.items.append({"id": i, "rect": pygame.Rect(x, y, 60, 60), "type": typ, "done": False, "angle": random.randint(-20, 20)})
        self.target = len(self.items)
        self.cleared = set()
        self.flow_amount = 0.0
        self.water_anim = 0.0
        self.particles = ParticleSystem()
        self.complete = False
        self.local_score = 0

    def update(self, dt):
        self.water_anim += dt
        self.particles.update(dt)
        self.flow_amount = len(self.cleared) / self.target
        self.common_update(dt)
        if len(self.cleared) == self.target and not self.complete:
            self.mark_completed("Drain Defender")
            self.set_message("Water can flow again.", 2.6)

    def handle_event(self, event):
        self.handle_back_button(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for item in self.items:
                if not item["done"] and item["rect"].collidepoint(event.pos):
                    item["done"] = True
                    self.cleared.add(item["id"])
                    self.award_points(18)
                    self.particles.emit_burst(item["rect"].centerx, item["rect"].centery, TURQUOISE, count=10, speed=90)
                    self.game.audio.play("collect")
                    self.set_message("Blockage removed", 1.2)
                    break

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, (26, 45, 58))
        surface.blit(bg, (0, 0))
        pygame.draw.rect(surface, (70, 76, 86), (0, 280, WIDTH, 440))
        for y in [360, 490, 620]:
            pygame.draw.line(surface, (90, 96, 106), (0, y), (WIDTH, y), 2)
        for x in range(0, WIDTH, 80):
            pygame.draw.line(surface, (90, 96, 106), (x, 280), (x, 720), 1)
        puddle_h = int(170 * (1.0 - self.flow_amount * 0.82))
        puddle_rect = pygame.Rect(340, 300, 620, puddle_h)
        pygame.draw.ellipse(surface, lerp_color((90, 110, 120), (60, 160, 190), self.flow_amount), puddle_rect)
        drain_rect = pygame.Rect(570, 430, 150, 90)
        pygame.draw.rect(surface, (50, 58, 68), drain_rect, border_radius=8)
        for i in range(11):
            x = drain_rect.x + 10 + i * 12
            pygame.draw.line(surface, (120, 130, 140), (x, drain_rect.y + 10), (x, drain_rect.bottom - 10), 4)
        flow_lines = int(self.flow_amount * 8)
        for i in range(flow_lines):
            sx = 420 + i * 55
            sy = 320 + math.sin(self.water_anim * 5 + i) * 8
            pygame.draw.line(surface, ELECTRIC_CYAN, (sx, sy), (drain_rect.centerx, drain_rect.centery), 2)
        if self.flow_amount > 0:
            for i in range(5):
                rr = 14 + i * 10 + int(math.sin(self.water_anim * 3 + i) * 2)
                pygame.draw.circle(surface, (150, 230, 240), (drain_rect.centerx, drain_rect.centery + 34), rr, 1)
        for x, y in [(400, 560), (1020, 590), (260, 470), (1120, 380)]:
            pygame.draw.ellipse(surface, (100, 120, 130), (x, y, 46, 18))
        for item in self.items:
            if not item["done"]:
                draw_waste_item(surface, item["type"], item["rect"], item["angle"])
        self.particles.draw(surface)
        self.common_draw(surface, "Mission 2 — Unclog the Drain", "Click each obstruction near the storm drain. Cleaner drains help rainwater flow and reduce local flooding.", TURQUOISE)
        draw_panel(surface, pygame.Rect(24, 620, 450, 74))
        txt = self.game.fonts["body"].render(f"Remaining blockage items: {self.target - len(self.cleared)}", True, WHITE)
        surface.blit(txt, (42, 640))
        draw_progress_bar(surface, pygame.Rect(42, 670, 410, 14), len(self.cleared), self.target, TURQUOISE)


class PlantMission(MissionBase):
    def __init__(self, game):
        super().__init__(game, "plant")
        self.reset_local()

    def reset_local(self):
        self.spot = pygame.Rect(560, 430, 150, 110)
        self.stage = 0  # 0 choose, 1 prepare, 2 plant, 3 water, 4 growing, 5 complete
        self.growth = 0.0
        self.greening = 0.0
        self.particles = ParticleSystem()
        self.complete = False
        self.local_score = 0
        self.water_button = Button((940, 610, 220, 54), "Water Sapling", self.water_action, accent=SOFT_MINT)

    def water_action(self):
        if self.stage == 3:
            self.stage = 4
            self.award_points(20)
            self.game.audio.play("water")
            self.particles.emit_droplets(self.spot.centerx, self.spot.y + 10, ICE_BLUE, count=24)
            self.set_message("Watering the sapling...", 1.4)
        else:
            self.game.audio.play("error")
            self.set_message("Complete the earlier steps first.", 1.2)

    def update(self, dt):
        self.common_update(dt)
        self.particles.update(dt)
        if self.stage == 4:
            self.growth += dt * 0.45
            self.greening = clamp(self.growth, 0, 1)
            if random.random() < 0.2:
                self.particles.emit_burst(self.spot.centerx + random.randint(-30, 30), self.spot.y + 20, SOFT_MINT, count=2, speed=25, life=1.0)
            if self.growth >= 1.0:
                self.stage = 5
                if not self.complete:
                    self.award_points(40)
                    self.mark_completed("Tree Planter")
                    self.set_message("The sapling has grown into a young tree!", 3.0)
                    self.game.audio.play("complete")

    def handle_event(self, event):
        self.handle_back_button(event)
        self.water_button.handle_event(event, self.game.audio)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.spot.collidepoint(event.pos):
                if self.stage == 0:
                    self.stage = 1
                    self.award_points(10)
                    self.game.audio.play("click")
                    self.set_message("Spot selected. Prepare the soil.", 1.6)
                elif self.stage == 1:
                    self.stage = 2
                    self.award_points(15)
                    self.particles.emit_burst(self.spot.centerx, self.spot.centery, GOLD, count=12, speed=85, life=0.8)
                    self.game.audio.play("plant")
                    self.set_message("Soil prepared. Plant the sapling.", 1.6)
                elif self.stage == 2:
                    self.stage = 3
                    self.award_points(20)
                    self.game.audio.play("plant")
                    self.particles.emit_burst(self.spot.centerx, self.spot.centery, SOFT_GREEN, count=14, speed=80, life=0.9)
                    self.set_message("Sapling planted. Now water it.", 1.6)

    def draw_growing_tree(self, surface):
        x = self.spot.centerx
        y = self.spot.centery + 20
        soil = pygame.Rect(self.spot.x + 18, self.spot.y + 52, self.spot.width - 36, 28)
        pygame.draw.ellipse(surface, (95, 63, 42), soil)
        if self.stage >= 2:
            trunk_h = int(lerp(16, 86, self.growth if self.stage >= 4 else 0.15))
            trunk_w = int(lerp(4, 14, self.growth if self.stage >= 4 else 0.15))
            pygame.draw.rect(surface, (108, 72, 40), (x - trunk_w // 2, y - trunk_h, trunk_w, trunk_h), border_radius=4)
        if self.stage >= 3:
            leaf_t = self.growth if self.stage >= 4 else 0.2
            for dx, dy, r in [(-16, -58, 15), (0, -74, 22), (18, -56, 14), (-4, -44, 16)]:
                rr = max(4, int(r * (0.2 + 0.8 * leaf_t)))
                pygame.draw.circle(surface, lerp_color((80, 150, 90), SOFT_MINT, leaf_t * 0.6), (int(x + dx), int(y + dy * leaf_t)), rr)
        if self.stage == 1:
            for i in range(4):
                pygame.draw.arc(surface, GOLD, (self.spot.x + 20 + i * 22, self.spot.y + 46, 18, 18), 0, math.pi, 2)

    def draw(self, surface):
        sky = vertical_gradient((WIDTH, HEIGHT), (14, 28, 48), (42, 88, 104))
        surface.blit(sky, (0, 0))
        pygame.draw.rect(surface, lerp_color((64, 120, 72), SOFT_MINT, self.greening * 0.3), (0, 380, WIDTH, 340))
        for i in range(7):
            draw_building(surface, 40 + i * 180, 360, 120, 80 + (i * 18 % 130), (24, 48, 72), (80, 180, 220), i + 220)
        for x in range(80, 1220, 160):
            draw_tree(surface, x, 392, scale=0.75, lush=0.5 + self.greening * 0.5)
        pygame.draw.rect(surface, (102, 160, 98), (0, 520, WIDTH, 200))
        plant_zone = pygame.Rect(420, 390, 430, 220)
        rounded_rect(surface, plant_zone, (88, 135, 84), radius=24, border=3, border_color=(150, 210, 160))
        for i in range(9):
            pygame.draw.arc(surface, (110, 170, 105), (430 + i * 42, 562, 40, 24), 0, math.pi, 2)
        pygame.draw.ellipse(surface, (92, 65, 48), self.spot)
        if self.stage == 0:
            pygame.draw.ellipse(surface, ELECTRIC_CYAN, self.spot.inflate(10, 10), 3)
        self.draw_growing_tree(surface)
        if self.greening > 0.15:
            for i in range(7):
                draw_reed(surface, 500 + i * 26, 594, int(18 + self.greening * 20))
        if self.greening > 0.55:
            for i in range(8):
                pygame.draw.circle(surface, SOFT_MINT, (450 + i * 40, 605 - int(math.sin(i) * 10)), 5)
        self.particles.draw(surface)
        self.common_draw(surface, "Mission 3 — Plant a Greener Future", "Click the marked spot to choose it, click again to prepare soil, click again to plant, then use the water button and watch it grow.", SOFT_MINT)
        stages = ["Choose spot", "Prepare soil", "Plant sapling", "Water sapling", "Watch it grow"]
        draw_panel(surface, pygame.Rect(900, 520, 330, 164))
        step_y = 542
        for i, step in enumerate(stages):
            done = self.stage > i
            current = self.stage == i
            col = SOFT_MINT if done or current else (150, 160, 170)
            bullet = "●" if current else ("✓" if done else "○")
            txt = self.game.fonts["body"].render(f"{bullet} {step}", True, col)
            surface.blit(txt, (922, step_y + i * 24))
        self.water_button.enabled = self.stage >= 3 and self.stage < 5
        self.water_button.draw(surface, self.game.fonts)
        draw_progress_bar(surface, pygame.Rect(922, 654, 280, 12), min(self.stage, 5), 5, SOFT_MINT)


class SortMission(MissionBase):
    def __init__(self, game):
        super().__init__(game, "sort")
        self.reset_local()

    def reset_local(self):
        self.classification = {
            "bottle": "recycle",
            "can": "recycle",
            "paper": "recycle",
            "cardboard": "recycle",
            "peel": "organic",
            "leaf": "organic",
            "wrapper": "general",
            "bag": "general",
        }
        types = ["bottle", "paper", "can", "cardboard", "peel", "leaf", "wrapper", "bag"]
        self.items = []
        for i, t in enumerate(types):
            self.items.append({
                "id": i,
                "type": t,
                "rect": pygame.Rect(120 + (i % 4) * 110, 250 + (i // 4) * 120, 80, 80),
                "home": (120 + (i % 4) * 110, 250 + (i // 4) * 120),
                "sorted": False,
                "angle": random.randint(-18, 18),
            })
        self.dragging = None
        self.offset = (0, 0)
        self.sorted_ids = set()
        self.target = len(self.items)
        self.feedback = "Drag each item into the correct bin."
        self.particles = ParticleSystem()
        self.complete = False
        self.local_score = 0
        self.bin_rects = {
            "recycle": pygame.Rect(760, 300, 140, 220),
            "organic": pygame.Rect(940, 300, 140, 220),
            "general": pygame.Rect(1120, 300, 140, 220),
        }

    def update(self, dt):
        self.common_update(dt)
        self.particles.update(dt)
        if len(self.sorted_ids) == self.target and not self.complete:
            self.mark_completed("Waste Sorter")
            self.set_message("All items sorted correctly!", 2.6)

    def handle_event(self, event):
        self.handle_back_button(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for item in reversed(self.items):
                if not item["sorted"] and item["rect"].collidepoint(event.pos):
                    self.dragging = item
                    self.offset = (event.pos[0] - item["rect"].x, event.pos[1] - item["rect"].y)
                    break
        elif event.type == pygame.MOUSEMOTION:
            if self.dragging:
                self.dragging["rect"].x = event.pos[0] - self.offset[0]
                self.dragging["rect"].y = event.pos[1] - self.offset[1]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.dragging:
                placed = False
                for bname, brect in self.bin_rects.items():
                    if brect.colliderect(self.dragging["rect"]):
                        placed = True
                        correct = self.classification[self.dragging["type"]] == bname
                        if correct and not self.dragging["sorted"]:
                            self.dragging["sorted"] = True
                            self.dragging["rect"].center = brect.center
                            self.sorted_ids.add(self.dragging["id"])
                            self.award_points(18)
                            self.feedback = f"Correct: {self.dragging['type'].title()} belongs in {bname.title()}."
                            self.particles.emit_burst(brect.centerx, brect.y + 36, SOFT_MINT if bname == "organic" else (ELECTRIC_CYAN if bname == "recycle" else CORAL), count=12, speed=80)
                            self.game.audio.play("sort")
                        else:
                            self.dragging["rect"].topleft = self.dragging["home"]
                            self.feedback = self.explain_wrong(self.dragging["type"], bname)
                            self.game.audio.play("error")
                        break
                if not placed and not self.dragging["sorted"]:
                    self.dragging["rect"].topleft = self.dragging["home"]
                self.dragging = None

    def explain_wrong(self, item_type, bname):
        target = self.classification[item_type]
        if item_type in ["bottle", "can", "paper", "cardboard"]:
            return f"Try again: clean {item_type}s are treated as recyclables."
        if item_type in ["peel", "leaf"]:
            return f"Try again: {item_type}s can break down as organic waste."
        return f"Try again: wrappers and plastic bags fit best in general waste here."

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DEEP_OCEAN)
        surface.blit(bg, (0, 0))
        pygame.draw.rect(surface, (52, 72, 90), (0, 220, WIDTH, 500))
        for i in range(9):
            pygame.draw.line(surface, (78, 100, 118), (0, 220 + i * 56), (WIDTH, 220 + i * 56), 1)
        draw_panel(surface, pygame.Rect(60, 220, 500, 320))
        for item in self.items:
            if not item["sorted"] or item is self.dragging:
                draw_waste_item(surface, item["type"], item["rect"], item["angle"], highlight=(item is self.dragging))
        active_bin = None
        if self.dragging:
            for bname, brect in self.bin_rects.items():
                if brect.colliderect(self.dragging["rect"]):
                    active_bin = bname
        draw_bin(surface, self.bin_rects["recycle"], SOFT_BLUE, "RECYCLABLES", active_bin == "recycle")
        draw_bin(surface, self.bin_rects["organic"], SOFT_GREEN, "ORGANIC", active_bin == "organic")
        draw_bin(surface, self.bin_rects["general"], SOFT_RED, "GENERAL", active_bin == "general")
        self.particles.draw(surface)
        self.common_draw(surface, "Mission 4 — Sort the Waste", "Drag each waste item into the correct bin. Wrong drops return the item and explain the rule so you can try again.", CORAL)
        draw_panel(surface, pygame.Rect(24, 620, 740, 74))
        txt = self.game.fonts["body"].render(self.feedback, True, WHITE)
        surface.blit(txt, (42, 640))
        draw_progress_bar(surface, pygame.Rect(42, 670, 700, 14), len(self.sorted_ids), self.target, CORAL)


class JourneyMission(MissionBase):
    def __init__(self, game):
        super().__init__(game, "journey")
        self.reset_local()

    def reset_local(self):
        self.choice = None
        self.result_shown = False
        self.complete = False
        self.local_score = 0
        self.options = [
            {"id": "car", "title": "Private Car", "impact": "Higher impact", "score": 10,
             "desc": "Convenient for some trips, but often uses more energy per person unless occupancy is high and the vehicle is efficient.", "rect": pygame.Rect(90, 480, 250, 170), "color": CORAL},
            {"id": "bus", "title": "Public Transport", "impact": "Lower impact", "score": 28,
             "desc": "Shared journeys can reduce per-person emissions, especially on busy, efficient routes.", "rect": pygame.Rect(380, 480, 250, 170), "color": TURQUOISE},
            {"id": "cycle", "title": "Cycling", "impact": "Very low impact", "score": 34,
             "desc": "Cycling avoids tailpipe emissions during travel and supports healthier streets for many short trips.", "rect": pygame.Rect(670, 480, 250, 170), "color": SOFT_MINT},
            {"id": "walk", "title": "Walking", "impact": "Very low impact", "score": 36,
             "desc": "Walking is often one of the lightest-impact choices for short local journeys and needs no fuel for the trip.", "rect": pygame.Rect(960, 480, 250, 170), "color": LAVENDER},
        ]

    def choose(self, opt):
        self.choice = opt
        if not self.result_shown:
            self.award_points(opt["score"])
            if self.id not in self.game.progress.completed_unique:
                self.mark_completed("Future Traveller")
            self.game.progress.travel_choice = opt["title"]
            self.result_shown = True
            self.set_message(f"You chose {opt['title']}", 2.4)
            self.game.audio.play("complete")

    def update(self, dt):
        self.common_update(dt)

    def handle_event(self, event):
        self.handle_back_button(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for opt in self.options:
                if opt["rect"].collidepoint(event.pos):
                    self.choose(opt)
                    break

    def draw_vehicle(self, surface, opt):
        r = opt["rect"]
        cx, cy = r.centerx, r.y + 70
        c = opt["color"]
        if opt["id"] == "car":
            pygame.draw.rect(surface, c, (cx - 58, cy - 10, 116, 34), border_radius=12)
            pygame.draw.polygon(surface, lerp_color(c, WHITE, 0.18), [(cx - 34, cy - 10), (cx + 12, cy - 10), (cx + 40, cy - 34), (cx - 10, cy - 34)])
            pygame.draw.circle(surface, BLACK, (cx - 35, cy + 26), 14)
            pygame.draw.circle(surface, BLACK, (cx + 35, cy + 26), 14)
        elif opt["id"] == "bus":
            pygame.draw.rect(surface, c, (cx - 68, cy - 26, 136, 60), border_radius=14)
            for i in range(4):
                pygame.draw.rect(surface, ICE_BLUE, (cx - 54 + i * 26, cy - 16, 18, 16), border_radius=3)
            pygame.draw.circle(surface, BLACK, (cx - 42, cy + 34), 12)
            pygame.draw.circle(surface, BLACK, (cx + 42, cy + 34), 12)
        elif opt["id"] == "cycle":
            pygame.draw.circle(surface, WHITE, (cx - 34, cy + 24), 24, 3)
            pygame.draw.circle(surface, WHITE, (cx + 36, cy + 24), 24, 3)
            pygame.draw.line(surface, c, (cx - 34, cy + 24), (cx, cy - 4), 4)
            pygame.draw.line(surface, c, (cx, cy - 4), (cx + 20, cy + 24), 4)
            pygame.draw.line(surface, c, (cx - 10, cy + 24), (cx + 36, cy + 24), 4)
            pygame.draw.line(surface, c, (cx, cy - 4), (cx - 10, cy + 24), 4)
            pygame.draw.line(surface, WHITE, (cx + 5, cy - 8), (cx + 24, cy - 18), 3)
        elif opt["id"] == "walk":
            pygame.draw.circle(surface, WHITE, (cx, cy - 34), 14)
            pygame.draw.line(surface, c, (cx, cy - 20), (cx, cy + 22), 6)
            pygame.draw.line(surface, c, (cx, cy - 4), (cx - 24, cy + 10), 5)
            pygame.draw.line(surface, c, (cx, cy - 4), (cx + 24, cy + 12), 5)
            pygame.draw.line(surface, c, (cx, cy + 22), (cx - 18, cy + 54), 5)
            pygame.draw.line(surface, c, (cx, cy + 22), (cx + 20, cy + 52), 5)

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DARK_TEAL)
        surface.blit(bg, (0, 0))
        for i in range(9):
            draw_building(surface, 10 + i * 140, 300, 100, 130 + (i * 27 % 150), (22, 40, 62), (90, 170, 220), 400 + i)
        pygame.draw.rect(surface, (45, 52, 68), (0, 400, WIDTH, 160))
        pygame.draw.rect(surface, (190, 200, 215), (0, 476, WIDTH, 4))
        for x in range(0, WIDTH, 80):
            pygame.draw.rect(surface, (235, 235, 210), (x + 18, 472, 34, 8), border_radius=3)
        pygame.draw.rect(surface, (72, 86, 100), (0, 560, WIDTH, 160))
        for x in range(60, WIDTH, 160):
            draw_tree(surface, x, 402, scale=0.7, lush=0.9)
        for x in [220, 820]:
            pygame.draw.rect(surface, (210, 230, 245), (x, 330, 8, 110))
            pygame.draw.circle(surface, GOLD, (x + 4, 334), 8)
        for opt in self.options:
            rounded_rect(surface, opt["rect"], lerp_color((22, 30, 42), opt["color"], 0.2), radius=18, border=3, border_color=opt["color"])
            self.draw_vehicle(surface, opt)
            title = self.game.fonts["sub"].render(opt["title"], True, WHITE)
            surface.blit(title, (opt["rect"].x + 18, opt["rect"].y + 100))
            impact = self.game.fonts["small"].render(f"{opt['impact']}  •  +{opt['score']} pts", True, opt["color"])
            surface.blit(impact, (opt["rect"].x + 18, opt["rect"].y + 132))
        self.common_draw(surface, "Mission 5 — Choose Your Journey", "Click a travel option. The result panel explains its relative environmental impact using simplified game metrics.", LAVENDER)
        if self.choice:
            draw_panel(surface, pygame.Rect(730, 110, 500, 180))
            title = self.game.fonts["sub"].render(self.choice["title"], True, self.choice["color"])
            surface.blit(title, (754, 132))
            impact = self.game.fonts["body"].render(f"Relative impact: {self.choice['impact']}", True, WHITE)
            surface.blit(impact, (754, 168))
            score = self.game.fonts["body"].render(f"Score awarded: +{self.choice['score']}", True, GOLD)
            surface.blit(score, (754, 198))
            draw_text(surface, self.choice["desc"], self.game.fonts["body"], ICE_BLUE, pygame.Rect(754, 230, 440, 56))


# ------------------------------------------------------------
# Screen system
# ------------------------------------------------------------

class ScreenBase:
    def __init__(self, game):
        self.game = game

    def enter(self):
        pass

    def update(self, dt):
        pass

    def draw(self, surface):
        pass

    def handle_event(self, event):
        pass


class TitleScreen(ScreenBase):
    def __init__(self, game):
        super().__init__(game)
        self.stars = [(random.randint(0, WIDTH), random.randint(0, 280), random.randint(1, 2), random.random() * math.tau) for _ in range(85)]
        self.time = 0.0
        self.play_button = Button((540, 520, 200, 58), "Play", self.play, accent=ELECTRIC_CYAN)
        self.music_button = Button((472, 595, 160, 46), "Music: On", self.toggle_music, accent=TURQUOISE, small=True)
        self.sfx_button = Button((652, 595, 156, 46), "SFX: On", self.toggle_sfx, accent=SOFT_MINT, small=True)
        self.vol_minus = Button((838, 595, 46, 46), "-", self.vol_down, accent=LAVENDER, small=True)
        self.vol_plus = Button((894, 595, 46, 46), "+", self.vol_up, accent=LAVENDER, small=True)

    def play(self):
        self.game.switch_screen(self.game.name_screen)

    def toggle_music(self):
        self.game.audio.toggle_music()
        self.music_button.text = f"Music: {'On' if self.game.audio.music_enabled else 'Off'}"

    def toggle_sfx(self):
        self.game.audio.toggle_sfx()
        self.sfx_button.text = f"SFX: {'On' if self.game.audio.sfx_enabled else 'Off'}"

    def vol_down(self):
        self.game.audio.set_volume(self.game.audio.volume - 0.1)

    def vol_up(self):
        self.game.audio.set_volume(self.game.audio.volume + 0.1)

    def update(self, dt):
        self.time += dt

    def handle_event(self, event):
        self.play_button.handle_event(event, self.game.audio)
        self.music_button.handle_event(event, self.game.audio)
        self.sfx_button.handle_event(event, self.game.audio)
        self.vol_minus.handle_event(event, self.game.audio)
        self.vol_plus.handle_event(event, self.game.audio)
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
            self.play()

    def draw(self, surface):
        draw_skyline(surface, self.time)
        draw_starfield(surface, self.stars, self.time)
        glow = radial_glow(220, ELECTRIC_CYAN, alpha=70)
        surface.blit(glow, (WIDTH // 2 - 220, 70))
        title = self.game.fonts["title"].render("2050: LETTERS FROM THE FUTURE", True, WHITE)
        subtitle = self.game.fonts["sub"].render("A cinematic 2D environmental adventure", True, ICE_BLUE)
        team = self.game.fonts["body"].render(f"Created by {TEAM}", True, GOLD)
        surface.blit(title, title.get_rect(center=(WIDTH // 2, 164)))
        surface.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 220)))
        surface.blit(team, team.get_rect(center=(WIDTH // 2, 254)))
        draw_panel(surface, pygame.Rect(300, 302, 680, 132))
        desc = "The future is not written yet. A mysterious letter from Jennifer in 2050 asks you to change the choices that shaped her world."
        draw_text(surface, desc, self.game.fonts["body"], WHITE, pygame.Rect(334, 334, 612, 70), align="center")
        self.play_button.draw(surface, self.game.fonts)
        self.music_button.draw(surface, self.game.fonts)
        self.sfx_button.draw(surface, self.game.fonts)
        self.vol_minus.draw(surface, self.game.fonts)
        self.vol_plus.draw(surface, self.game.fonts)
        vol = self.game.fonts["small"].render(f"Volume: {int(self.game.audio.volume * 100)}%", True, WHITE)
        surface.blit(vol, (954, 608))


class NameEntryScreen(ScreenBase):
    def __init__(self, game):
        super().__init__(game)
        self.input_box = InputBox((390, 320, 500, 62))
        self.continue_button = Button((540, 430, 200, 56), "Continue", self.submit, accent=ELECTRIC_CYAN)
        self.hint = ""

    def enter(self):
        self.hint = ""

    def submit(self):
        name = self.input_box.text.strip()
        if not name:
            name = "Friend"
        self.game.progress.player_name = name
        self.game.intro_letter.reset_with_name(name)
        self.game.switch_screen(self.game.intro_letter)

    def update(self, dt):
        self.input_box.update(dt)

    def handle_event(self, event):
        self.continue_button.handle_event(event, self.game.audio)
        res = self.input_box.handle_event(event)
        if res == "submit":
            self.submit()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.switch_screen(self.game.title_screen)

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DEEP_OCEAN)
        surface.blit(bg, (0, 0))
        draw_panel(surface, pygame.Rect(260, 180, 760, 340))
        title = self.game.fonts["title_small"].render("Before the letter arrives...", True, WHITE)
        surface.blit(title, title.get_rect(center=(WIDTH // 2, 240)))
        prompt = "Enter your name so Jennifer can address her message to you."
        surface.blit(self.game.fonts["body"].render(prompt, True, ICE_BLUE), (392, 282))
        self.input_box.draw(surface, self.game.fonts)
        note = self.game.fonts["small"].render("Press Enter to continue. Empty input will use 'Friend'.", True, GOLD)
        surface.blit(note, (420, 392))
        self.continue_button.draw(surface, self.game.fonts)


class LetterScreen(ScreenBase):
    def __init__(self, game, title, body_template, next_screen_getter: Callable[[], ScreenBase]):
        super().__init__(game)
        self.title_text = title
        self.body_template = body_template
        self.next_screen_getter = next_screen_getter
        self.letter = TypewriterLetter(title, body_template)

    def reset_with_name(self, name):
        body = self.body_template.format(name=name)
        self.letter = TypewriterLetter(self.title_text, body)

    def update(self, dt):
        self.letter.update(dt)

    def handle_event(self, event):
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            if event.type == pygame.KEYDOWN and event.key not in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                return
            if not self.letter.done:
                self.letter.reveal_all()
            else:
                self.game.switch_screen(self.next_screen_getter())

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DARK_TEAL)
        surface.blit(bg, (0, 0))
        glow = radial_glow(240, LAVENDER, alpha=60)
        surface.blit(glow, (160, 90))
        self.letter.draw(surface, self.game.fonts, pygame.Rect(170, 80, 940, 560))


class HubScreen(ScreenBase):
    def __init__(self, game):
        super().__init__(game)
        self.buttons = {}
        self.final_button = Button((980, 620, 250, 56), "Final Letter", self.open_final, accent=GOLD)
        self.title_button = Button((28, 620, 180, 52), "Return to Title", self.to_title, accent=LAVENDER, small=True)
        self.music_button = Button((220, 620, 140, 52), "Music", self.toggle_music, accent=TURQUOISE, small=True)
        self.sfx_button = Button((372, 620, 120, 52), "SFX", self.toggle_sfx, accent=SOFT_MINT, small=True)
        cards = [(70, 170), (475, 170), (880, 170), (270, 390), (675, 390)]
        for (mid, pos) in zip(MISSION_IDS, cards):
            self.buttons[mid] = Button((pos[0], pos[1] + 178, 290, 48), "Open Mission", action=lambda m=mid: self.open_mission(m), accent=MISSION_ACCENTS[mid], small=True)

    def open_mission(self, mission_id):
        mission = self.game.missions[mission_id]
        mission.reset_local()
        self.game.switch_screen(mission)

    def open_final(self):
        if len(self.game.progress.completed_unique) >= 4:
            self.game.final_letter.reset_with_name(self.game.progress.player_name or "Friend")
            self.game.switch_screen(self.game.final_letter)

    def to_title(self):
        self.game.new_game()
        self.game.switch_screen(self.game.title_screen)

    def toggle_music(self):
        self.game.audio.toggle_music()

    def toggle_sfx(self):
        self.game.audio.toggle_sfx()

    def handle_event(self, event):
        for btn in self.buttons.values():
            btn.handle_event(event, self.game.audio)
        self.final_button.enabled = len(self.game.progress.completed_unique) >= 4
        self.final_button.handle_event(event, self.game.audio)
        self.title_button.handle_event(event, self.game.audio)
        self.music_button.handle_event(event, self.game.audio)
        self.sfx_button.handle_event(event, self.game.audio)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.to_title()

    def draw_card(self, surface, rect, mission_id):
        accent = MISSION_ACCENTS[mission_id]
        rounded_rect(surface, rect, lerp_color((20, 28, 42), accent, 0.10), radius=24, border=3, border_color=accent)
        status = "COMPLETED" if mission_id in self.game.progress.completed_unique else "NEW"
        if mission_id in self.game.progress.completed_unique:
            badge_col = SOFT_MINT
        else:
            badge_col = GOLD
        badge = pygame.Rect(rect.x + 18, rect.y + 14, 110, 28)
        rounded_rect(surface, badge, lerp_color((35, 50, 68), badge_col, 0.22), radius=12)
        surface.blit(self.game.fonts["small"].render(status, True, WHITE), (badge.x + 16, badge.y + 5))
        surface.blit(self.game.fonts["small"].render(MISSION_SDG[mission_id], True, accent), (rect.right - 92, rect.y + 20))
        title = self.game.fonts["sub"].render(MISSION_TITLES[mission_id], True, WHITE)
        surface.blit(title, (rect.x + 18, rect.y + 54))
        draw_text(surface, MISSION_DESC[mission_id], self.game.fonts["body"], ICE_BLUE, pygame.Rect(rect.x + 18, rect.y + 92, rect.width - 36, 62))
        ix, iy = rect.x + rect.width - 92, rect.y + 102
        if mission_id == "river":
            pygame.draw.arc(surface, ELECTRIC_CYAN, (ix - 30, iy, 90, 50), 0, math.pi, 4)
            pygame.draw.circle(surface, WHITE, (ix + 10, iy + 26), 7)
        elif mission_id == "drain":
            pygame.draw.rect(surface, TURQUOISE, (ix - 18, iy + 10, 54, 36), border_radius=8)
            for j in range(4):
                pygame.draw.line(surface, WHITE, (ix - 8 + j * 12, iy + 14), (ix - 8 + j * 12, iy + 42), 3)
        elif mission_id == "plant":
            draw_tree(surface, ix + 10, iy + 60, scale=0.55, lush=1)
        elif mission_id == "sort":
            pygame.draw.rect(surface, SOFT_BLUE, (ix - 26, iy + 14, 24, 42), border_radius=6)
            pygame.draw.rect(surface, SOFT_GREEN, (ix + 2, iy + 14, 24, 42), border_radius=6)
            pygame.draw.rect(surface, SOFT_RED, (ix + 30, iy + 14, 24, 42), border_radius=6)
        elif mission_id == "journey":
            pygame.draw.circle(surface, WHITE, (ix - 6, iy + 44), 14, 3)
            pygame.draw.circle(surface, WHITE, (ix + 34, iy + 44), 14, 3)
            pygame.draw.line(surface, LAVENDER, (ix - 6, iy + 44), (ix + 14, iy + 18), 3)
            pygame.draw.line(surface, LAVENDER, (ix + 14, iy + 18), (ix + 34, iy + 44), 3)
        self.buttons[mission_id].rect.topleft = (rect.x + 18, rect.bottom - 62)
        self.buttons[mission_id].draw(surface, self.game.fonts)

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DEEP_OCEAN)
        surface.blit(bg, (0, 0))
        header_glow = radial_glow(180, ELECTRIC_CYAN, alpha=50)
        surface.blit(header_glow, (30, 10))
        title = self.game.fonts["title_small"].render("Mission Hub", True, WHITE)
        surface.blit(title, (34, 28))
        player = self.game.progress.player_name or "Friend"
        stats = f"Player: {player}    Score: {self.game.progress.score}    Unique missions completed: {len(self.game.progress.completed_unique)} / 5"
        surface.blit(self.game.fonts["body"].render(stats, True, ICE_BLUE), (36, 78))
        prompt = "Complete any four unique missions to unlock Jennifer's final letter."
        surface.blit(self.game.fonts["body"].render(prompt, True, GOLD), (36, 110))
        card_rects = {
            "river": pygame.Rect(60, 160, 330, 250),
            "drain": pygame.Rect(475, 160, 330, 250),
            "plant": pygame.Rect(890, 160, 330, 250),
            "sort": pygame.Rect(265, 430, 330, 250),
            "journey": pygame.Rect(680, 430, 330, 250),
        }
        for mid, rect in card_rects.items():
            self.draw_card(surface, rect, mid)
        self.final_button.enabled = len(self.game.progress.completed_unique) >= 4
        if self.final_button.enabled:
            self.final_button.text = "Final Letter Unlocked"
        else:
            self.final_button.text = "Final Letter Locked"
        self.final_button.draw(surface, self.game.fonts)
        self.title_button.draw(surface, self.game.fonts)
        self.music_button.text = f"Music: {'On' if self.game.audio.music_enabled else 'Off'}"
        self.sfx_button.text = f"SFX: {'On' if self.game.audio.sfx_enabled else 'Off'}"
        self.music_button.draw(surface, self.game.fonts)
        self.sfx_button.draw(surface, self.game.fonts)


class FinalLetterScreen(ScreenBase):
    def __init__(self, game):
        super().__init__(game)
        self.time = 0.0
        body = (
            "Dear {name},\n\n"
            "Your choices reached me. The river near my home is brighter now, trees are returning, and our streets feel more alive. You did not fix everything alone — no one can — but you proved something powerful: when people act together, the future can change.\n\n"
            "The future is not written yet. Every choice matters.\n\n"
            "Thank you for helping us remember what hope looks like.\n\n"
            "— Jennifer, 2050"
        )
        self.letter = TypewriterLetter("Jennifer's Final Letter", body)

    def reset_with_name(self, name):
        body = (
            f"Dear {name},\n\n"
            "Your choices reached me. The river near my home is brighter now, trees are returning, and our streets feel more alive. You did not fix everything alone — no one can — but you proved something powerful: when people act together, the future can change.\n\n"
            "The future is not written yet. Every choice matters.\n\n"
            "Thank you for helping us remember what hope looks like.\n\n"
            "— Jennifer, 2050"
        )
        self.letter = TypewriterLetter("Jennifer's Final Letter", body)
        self.time = 0.0

    def update(self, dt):
        self.time += dt
        self.letter.update(dt)

    def handle_event(self, event):
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            if event.type == pygame.KEYDOWN and event.key not in (pygame.K_RETURN, pygame.K_SPACE):
                return
            if not self.letter.done:
                self.letter.reveal_all()
            else:
                self.game.switch_screen(self.game.results_screen)

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), (8, 18, 30), (36, 96, 88))
        surface.blit(bg, (0, 0))
        for i in range(8):
            draw_building(surface, 20 + i * 160, 300, 110, 110 + (i * 24 % 140), (22, 46, 68), (120, 220, 240), 600 + i)
        river_col = lerp_color((60, 130, 145), (90, 220, 210), 0.7 + 0.2 * math.sin(self.time))
        pygame.draw.polygon(surface, river_col, [(0, 450), (180, 430), (370, 454), (640, 420), (890, 462), (1180, 440), (1280, 450), (1280, 720), (0, 720)])
        for i in range(14):
            pygame.draw.line(surface, ICE_BLUE, (i * 90, 500 + math.sin(self.time * 3 + i) * 6), (i * 90 + 60, 504 + math.sin(self.time * 3 + i) * 6), 2)
        draw_bridge(surface, 320, 330, 920, 110, glow=True)
        for x in range(90, 1180, 130):
            draw_tree(surface, x, 430, scale=0.82, lush=1)
        self.letter.draw(surface, self.game.fonts, pygame.Rect(170, 76, 940, 540))


class ResultsScreen(ScreenBase):
    def __init__(self, game):
        super().__init__(game)
        self.replay_button = Button((430, 610, 200, 56), "Replay Game", self.replay, accent=ELECTRIC_CYAN)
        self.title_button = Button((650, 610, 220, 56), "Return to Title", self.to_title, accent=LAVENDER)

    def replay(self):
        self.game.new_game(keep_name=True)
        self.game.switch_screen(self.game.hub)

    def to_title(self):
        self.game.new_game()
        self.game.switch_screen(self.game.title_screen)

    def handle_event(self, event):
        self.replay_button.handle_event(event, self.game.audio)
        self.title_button.handle_event(event, self.game.audio)

    def draw(self, surface):
        bg = vertical_gradient((WIDTH, HEIGHT), MIDNIGHT, DEEP_OCEAN)
        surface.blit(bg, (0, 0))
        draw_panel(surface, pygame.Rect(180, 90, 920, 500))
        player = self.game.progress.player_name or "Friend"
        title = self.game.fonts["title_small"].render("A Hopeful Future", True, WHITE)
        surface.blit(title, title.get_rect(center=(WIDTH // 2, 140)))
        lines = [
            f"Player: {player}",
            f"Unique missions completed: {len(self.game.progress.completed_unique)} / 5",
            f"Total score: {self.game.progress.score}",
            "Completed missions: " + ", ".join(MISSION_TITLES[m] for m in self.game.progress.completed_unique),
            "Environmental achievements: " + (", ".join(self.game.progress.achievements) if self.game.progress.achievements else "None yet"),
            "SDGs addressed: " + (", ".join(sorted(self.game.progress.sdgs)) if self.game.progress.sdgs else "None"),
        ]
        y = 210
        for i, line in enumerate(lines):
            rect = pygame.Rect(240, y, 800, 36 if i < 3 else 70)
            draw_text(surface, line, self.game.fonts["sub"] if i < 3 else self.game.fonts["body"], GOLD if i == 2 else ICE_BLUE, rect)
            y += 58 if i < 3 else 82
        summary = (
            "Illustrative impact summary: your actions restored a river, cleared flood-causing waste, supported urban greening, improved waste sorting, and explored transport choices. Individual action matters most when communities act together."
        )
        draw_text(surface, summary, self.game.fonts["body"], WHITE, pygame.Rect(240, 470, 800, 70))
        self.replay_button.draw(surface, self.game.fonts)
        self.title_button.draw(surface, self.game.fonts)


# ------------------------------------------------------------
# Main game class
# ------------------------------------------------------------

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.fonts = {
            "title": pygame.font.SysFont("georgia", 46, bold=True),
            "title_small": pygame.font.SysFont("georgia", 34, bold=True),
            "sub": pygame.font.SysFont("arial", 26, bold=True),
            "body": pygame.font.SysFont("arial", 22),
            "small": pygame.font.SysFont("arial", 16),
        }
        self.audio = SafeAudio()
        self.progress = ProgressData()
        self.title_screen = TitleScreen(self)
        self.name_screen = NameEntryScreen(self)
        intro_body = (
            "Dear {name},\n\n"
            "My name is Jennifer, and I am writing to you from the year 2050. The river near my home has almost disappeared. Rubbish blocks our drains when storms come. Trees that once cooled our streets are gone, and many neighbourhoods feel harder to live in.\n\n"
            "I found old records showing that the future changed because of ordinary decisions made years before I was born. If you act now, maybe my world does not have to stay this way.\n\n"
            "Please help me repair what is still possible to repair.\n\n"
            "— Jennifer"
        )
        self.intro_letter = LetterScreen(self, "A Letter from Jennifer", intro_body, lambda: self.hub)
        self.hub = HubScreen(self)
        self.missions = {
            "river": RiverMission(self),
            "drain": DrainMission(self),
            "plant": PlantMission(self),
            "sort": SortMission(self),
            "journey": JourneyMission(self),
        }
        self.final_letter = FinalLetterScreen(self)
        self.results_screen = ResultsScreen(self)
        self.current_screen: ScreenBase = self.title_screen
        self.current_screen.enter()

    def switch_screen(self, screen):
        self.current_screen = screen
        self.current_screen.enter()

    def new_game(self, keep_name=False):
        old_name = self.progress.player_name if keep_name else ""
        self.progress.reset()
        if keep_name:
            self.progress.player_name = old_name
        self.name_screen.input_box.text = old_name
        self.intro_letter.reset_with_name(old_name or "Friend")
        for m in self.missions.values():
            m.reset_local()

    def run(self):
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.current_screen.handle_event(event)
            self.audio.update(dt)
            self.current_screen.update(dt)
            self.current_screen.draw(self.screen)
            pygame.display.flip()
        pygame.quit()


def main():
    Game().run()


if __name__ == "__main__":
    main()
