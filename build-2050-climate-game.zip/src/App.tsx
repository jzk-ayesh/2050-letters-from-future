import { Canvas, useFrame } from '@react-three/fiber';
import { Float, OrbitControls, RoundedBox, Sky, Text } from '@react-three/drei';
import { useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import * as THREE from 'three';

type MissionCardProps = {
  title: string;
  description: string;
  progress: number;
  goal: number;
  accent: string;
  complete: boolean;
  children?: ReactNode;
};

type WorldState = {
  trashCleaned: number;
  treesPlanted: number;
  recycleBoost: number;
};

function River({ cleanRatio }: { cleanRatio: number }) {
  const water = useMemo(
    () => new THREE.Color().lerpColors(new THREE.Color('#5b4a3a'), new THREE.Color('#4fd1ff'), cleanRatio),
    [cleanRatio],
  );

  return (
    <group position={[0, -1.6, 0]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[18, 4.5, 1, 1]} />
        <meshStandardMaterial color={water} metalness={0.15} roughness={0.2} />
      </mesh>
      <mesh position={[0, -0.05, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <ringGeometry args={[1.5, 5.8, 64]} />
        <meshStandardMaterial color="#59a14f" />
      </mesh>
    </group>
  );
}

function FloatingTrash({ position, collected }: { position: [number, number, number]; collected: boolean }) {
  const meshRef = useRef<THREE.Group | null>(null);

  useFrame(({ clock }) => {
    if (!meshRef.current || collected) return;
    meshRef.current.position.y = position[1] + Math.sin(clock.elapsedTime * 2 + position[0]) * 0.05;
    meshRef.current.rotation.y += 0.01;
  });

  if (collected) return null;

  return (
    <group ref={meshRef} position={position}>
      <mesh castShadow>
        <boxGeometry args={[0.35, 0.18, 0.22]} />
        <meshStandardMaterial color="#dbe4ee" metalness={0.8} roughness={0.25} />
      </mesh>
      <mesh position={[0, 0.14, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 0.08, 24]} />
        <meshStandardMaterial color="#fb7185" />
      </mesh>
    </group>
  );
}

function Tree({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  return (
    <group position={position} scale={scale}>
      <mesh castShadow position={[0, 0.45, 0]}>
        <cylinderGeometry args={[0.13, 0.18, 0.9, 18]} />
        <meshStandardMaterial color="#7c4a21" />
      </mesh>
      <mesh castShadow position={[0, 1.2, 0]}>
        <coneGeometry args={[0.7, 1.35, 18]} />
        <meshStandardMaterial color="#22c55e" />
      </mesh>
      <mesh castShadow position={[0, 1.65, 0]}>
        <coneGeometry args={[0.55, 1.05, 18]} />
        <meshStandardMaterial color="#16a34a" />
      </mesh>
    </group>
  );
}

function Sapling({ position }: { position: [number, number, number] }) {
  return <Tree position={position} scale={0.9} />;
}

function RecyclingOrb({ energy }: { energy: number }) {
  const ref = useRef<THREE.Group | null>(null);

  useFrame(({ clock }) => {
    if (!ref.current) return;
    ref.current.rotation.y += 0.012;
    ref.current.position.y = 1.4 + Math.sin(clock.elapsedTime * 2.4) * 0.08;
  });

  const glow = Math.min(1, 0.25 + energy * 0.18);
  const orbColor = new THREE.Color(80 / 255 + glow * 0.24, 220 / 255, 140 / 255 + glow * 0.31);

  return (
    <group ref={ref} position={[5.2, 1.4, 0.6]}>
      <mesh castShadow>
        <icosahedronGeometry args={[0.75, 0]} />
        <meshStandardMaterial
          color={orbColor}
          emissive="#34d399"
          emissiveIntensity={0.5 + glow}
          roughness={0.2}
          metalness={0.7}
        />
      </mesh>
      <Text position={[0, -1.25, 0]} fontSize={0.22} color="#d1fae5" anchorX="center">
        ECO CORE
      </Text>
    </group>
  );
}

function Terrain() {
  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial color="#65a30d" />
      </mesh>
      <mesh position={[-5, -1.25, -3]} rotation={[-0.15, 0.5, 0]} receiveShadow>
        <boxGeometry args={[5, 1.4, 3]} />
        <meshStandardMaterial color="#84cc16" />
      </mesh>
      <mesh position={[6, -1.1, 3]} rotation={[0.1, -0.45, 0]} receiveShadow>
        <boxGeometry args={[4.4, 1.1, 3]} />
        <meshStandardMaterial color="#a3e635" />
      </mesh>
    </>
  );
}

function Scene({ state }: { state: WorldState }) {
  const cleanRatio = Math.min(1, state.trashCleaned / 6);
  const trees = Array.from({ length: state.treesPlanted });
  const trashPositions: [number, number, number][] = [
    [-2.6, -1.15, -0.8],
    [-1.5, -1.1, 0.2],
    [0.15, -1.18, -0.3],
    [1.8, -1.12, 0.5],
    [3.1, -1.1, -0.5],
    [4.2, -1.15, 0.1],
  ];

  return (
    <Canvas shadows camera={{ position: [7.5, 5.5, 8.5], fov: 46 }}>
      <color attach="background" args={['#06131f']} />
      <fog attach="fog" args={['#06131f', 10, 28]} />
      <ambientLight intensity={0.75} />
      <directionalLight
        castShadow
        position={[8, 12, 5]}
        intensity={1.5}
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <Sky sunPosition={[5, 2, 8]} turbidity={6} rayleigh={0.7} />
      <Terrain />
      <River cleanRatio={cleanRatio} />
      {trashPositions.map((position, index) => (
        <FloatingTrash key={position.join('-')} position={position} collected={index < state.trashCleaned} />
      ))}
      <Float speed={2} rotationIntensity={0.6} floatIntensity={0.5}>
        <RoundedBox args={[1.4, 1.4, 1.4]} radius={0.18} smoothness={4} position={[-5.6, 0.4, 3.3]} castShadow>
          <meshStandardMaterial
            color="#2563eb"
            metalness={0.65}
            roughness={0.18}
            emissive="#1d4ed8"
            emissiveIntensity={0.4}
          />
        </RoundedBox>
      </Float>
      <RecyclingOrb energy={state.recycleBoost} />
      <Tree position={[-6.2, -0.5, -5.2]} scale={1.2} />
      <Tree position={[-7.4, -0.7, 1.5]} scale={0.95} />
      <Tree position={[7.5, -0.65, -4.2]} scale={1.15} />
      <Tree position={[6.8, -0.6, 5.5]} scale={1} />
      {trees.map((_, index) => {
        const x = -3.6 + (index % 4) * 1.35;
        const z = 4.8 + Math.floor(index / 4) * 1.2;
        return <Sapling key={`tree-${index}`} position={[x, -0.62, z]} />;
      })}
      <Text position={[0, 3.8, -2]} fontSize={0.55} color="#dcfce7" anchorX="center">
        EcoVerse 3D Rescue
      </Text>
      <Text position={[0, 3.15, -2]} fontSize={0.22} color="#bfdbfe" anchorX="center">
        Clean the river • Plant the future • Power the eco core
      </Text>
      <OrbitControls enablePan={false} minDistance={9} maxDistance={15} minPolarAngle={0.8} maxPolarAngle={1.3} />
    </Canvas>
  );
}

function MissionCard({ title, description, progress, goal, accent, complete, children }: MissionCardProps) {
  const percent = Math.min(100, (progress / goal) * 100);

  return (
    <div className="rounded-3xl border border-white/10 bg-white/8 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.25)] backdrop-blur-xl">
      <div className="mb-3 flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <p className="text-sm text-slate-300">{description}</p>
        </div>
        <div
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            complete ? 'bg-emerald-400/20 text-emerald-200' : 'bg-white/10 text-slate-200'
          }`}
        >
          {complete ? 'Complete' : `${progress}/${goal}`}
        </div>
      </div>
      <div className="mb-4 h-2 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${percent}%`, background: accent }} />
      </div>
      {children}
    </div>
  );
}

export default function App() {
  const [state, setState] = useState<WorldState>({
    trashCleaned: 0,
    treesPlanted: 0,
    recycleBoost: 0,
  });

  const riverComplete = state.trashCleaned >= 6;
  const treesComplete = state.treesPlanted >= 6;
  const recycleComplete = state.recycleBoost >= 5;
  const allComplete = riverComplete && treesComplete && recycleComplete;

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_#12324a,_#07111b_48%,_#030712_100%)] text-white">
      <div className="mx-auto grid min-h-screen max-w-7xl gap-6 p-4 lg:grid-cols-[1.3fr_0.7fr] lg:p-6">
        <section className="relative overflow-hidden rounded-[2rem] border border-cyan-400/20 bg-white/5 shadow-2xl shadow-cyan-950/40">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(34,211,238,0.18),_transparent_28%),radial-gradient(circle_at_bottom_right,_rgba(16,185,129,0.15),_transparent_26%)]" />
          <div className="relative h-[58vh] min-h-[420px] w-full lg:h-full">
            <Scene state={state} />
          </div>
          <div className="pointer-events-none absolute left-4 top-4 rounded-2xl border border-white/10 bg-slate-950/55 px-4 py-3 backdrop-blur-md">
            <p className="text-xs uppercase tracking-[0.32em] text-cyan-200">3D mission mode</p>
            <h1 className="text-2xl font-bold text-white">EcoVerse Rewilding Ops</h1>
            <p className="mt-1 max-w-md text-sm text-slate-300">
              A full 3D-style eco rescue game with live mission progress, river restoration, working tree planting,
              and a powered-up futuristic vibe.
            </p>
          </div>
          {allComplete && (
            <div className="absolute inset-x-4 bottom-4 rounded-3xl border border-emerald-300/30 bg-emerald-400/15 p-4 backdrop-blur-xl">
              <p className="text-xs uppercase tracking-[0.3em] text-emerald-200">Planet saved</p>
              <p className="text-lg font-semibold text-white">
                All missions complete. The river glows, the forest grows, and the Eco Core is fully charged.
              </p>
            </div>
          )}
        </section>

        <aside className="flex flex-col gap-4 rounded-[2rem] border border-white/10 bg-white/6 p-4 shadow-2xl shadow-black/30 backdrop-blur-xl lg:p-5">
          <div>
            <p className="text-sm uppercase tracking-[0.32em] text-cyan-300">Mission control</p>
            <h2 className="mt-2 text-3xl font-black leading-tight">Make it 100x cooler</h2>
            <p className="mt-2 text-sm text-slate-300">
              Now upgraded from placeholder graphics into a dramatic 3D eco-action experience.
            </p>
          </div>

          <MissionCard
            title="River Trash Cleanup"
            description="Remove floating junk to restore crystal-clear water."
            progress={state.trashCleaned}
            goal={6}
            accent="linear-gradient(90deg, #38bdf8, #22d3ee)"
            complete={riverComplete}
          >
            <button
              onClick={() => setState((prev) => ({ ...prev, trashCleaned: Math.min(6, prev.trashCleaned + 1) }))}
              className="w-full rounded-2xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950 transition hover:scale-[1.02] hover:bg-cyan-300"
            >
              Collect River Trash
            </button>
          </MissionCard>

          <MissionCard
            title="Plant Trees"
            description="This mission is now fixed: every click plants a visible tree in the 3D world."
            progress={state.treesPlanted}
            goal={6}
            accent="linear-gradient(90deg, #4ade80, #22c55e)"
            complete={treesComplete}
          >
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setState((prev) => ({ ...prev, treesPlanted: Math.min(6, prev.treesPlanted + 1) }))}
                className="rounded-2xl bg-emerald-400 px-4 py-3 font-semibold text-emerald-950 transition hover:scale-[1.02] hover:bg-emerald-300"
              >
                Plant Tree
              </button>
              <button
                onClick={() => setState((prev) => ({ ...prev, treesPlanted: 0 }))}
                className="rounded-2xl border border-white/10 bg-white/8 px-4 py-3 font-semibold text-white transition hover:bg-white/12"
              >
                Reset Grove
              </button>
            </div>
          </MissionCard>

          <MissionCard
            title="Recycle Power Surge"
            description="Charge the Eco Core to unlock max visual energy."
            progress={state.recycleBoost}
            goal={5}
            accent="linear-gradient(90deg, #a78bfa, #34d399)"
            complete={recycleComplete}
          >
            <button
              onClick={() => setState((prev) => ({ ...prev, recycleBoost: Math.min(5, prev.recycleBoost + 1) }))}
              className="w-full rounded-2xl bg-violet-400 px-4 py-3 font-semibold text-violet-950 transition hover:scale-[1.02] hover:bg-violet-300"
            >
              Recycle + Charge Core
            </button>
          </MissionCard>

          <div className="mt-auto rounded-3xl border border-white/10 bg-slate-950/40 p-4">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm text-slate-300">World restoration</span>
              <span className="text-lg font-bold text-white">
                {Math.round(((state.trashCleaned + state.treesPlanted + state.recycleBoost) / 17) * 100)}%
              </span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-emerald-400 to-violet-400 transition-all duration-500"
                style={{ width: `${((state.trashCleaned + state.treesPlanted + state.recycleBoost) / 17) * 100}%` }}
              />
            </div>
            <p className="mt-3 text-sm text-slate-400">Tip: orbit the camera and watch the scene transform as each mission progresses.</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
